"""This module contains the speech recognition and speech synthesis functions."""
from autogpt.speech.say import say_text

__all__ = ["say_text"]
